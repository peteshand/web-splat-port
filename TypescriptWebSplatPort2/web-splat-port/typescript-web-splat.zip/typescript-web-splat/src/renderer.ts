import { mat4, vec2, vec4 } from 'gl-matrix';
import { Camera, PerspectiveCamera, VIEWPORT_Y_FLIP } from './camera.js';
import { PointCloud, Aabb } from './pointcloud.js';
import { UniformBuffer, UnifiedUniformBuffer } from './uniform.js';
import { GPUStopwatch } from './utils.js';

// Placeholder for GPURSSorter - will be implemented when porting gpu_rs.ts
interface GPURSSorter {
    createSortStuff(device: GPUDevice, numPoints: number): PointCloudSortStuff;
    recordResetIndirectBuffer(sorterDis: GPUBindGroup, sorterUni: GPUBuffer, queue: GPUQueue): void;
    recordSortIndirect(sorterBg: GPUBindGroup, sorterDis: GPUBindGroup, encoder: GPUCommandEncoder): void;
    bindGroupLayoutPreprocess(device: GPUDevice): GPUBindGroupLayout;
    bindGroupLayoutRendering(device: GPUDevice): GPUBindGroupLayout;
}

interface PointCloudSortStuff {
    numPoints: number;
    sorterBgPre: GPUBindGroup;
    sorterBg: GPUBindGroup;
    sorterDis: GPUBindGroup;
    sorterUni: GPUBuffer;
    sorterRenderBg: GPUBindGroup;
}

/**
 * Camera uniform data structure for GPU
 */
export class CameraUniform {
    public viewMatrix: mat4;
    public viewInvMatrix: mat4;
    public projMatrix: mat4;
    public projInvMatrix: mat4;
    public viewport: vec2;
    public focal: vec2;

    constructor() {
        this.viewMatrix = mat4.create();
        this.viewInvMatrix = mat4.create();
        this.projMatrix = mat4.create();
        this.projInvMatrix = mat4.create();
        this.viewport = vec2.fromValues(1.0, 1.0);
        this.focal = vec2.fromValues(1.0, 1.0);
    }

    setViewMat(viewMatrix: mat4): void {
        mat4.copy(this.viewMatrix, viewMatrix);
        mat4.invert(this.viewInvMatrix, viewMatrix);
    }

    setProjMat(projMatrix: mat4): void {
        const temp = mat4.create();
        mat4.multiply(temp, VIEWPORT_Y_FLIP, projMatrix);
        mat4.copy(this.projMatrix, temp);
        mat4.invert(this.projInvMatrix, projMatrix);
    }

    setCamera(camera: Camera): void {
        this.setProjMat(camera.projMatrix());
        this.setViewMat(camera.viewMatrix());
    }

    setViewport(viewport: vec2): void {
        vec2.copy(this.viewport, viewport);
    }

    setFocal(focal: vec2): void {
        vec2.copy(this.focal, focal);
    }
}

/**
 * Splatting arguments for rendering
 */
export interface SplattingArgs {
    camera: PerspectiveCamera;
    viewport: vec2;
    gaussianScaling: number;
    maxShDeg: number;
    showEnvMap: boolean;
    mipSplatting?: boolean;
    kernelSize?: number;
    clippingBox?: Aabb;
    walltime: number; // Duration in seconds
    sceneCenter?: [number, number, number];
    sceneExtend?: number;
    backgroundColor: GPUColor;
    resolution: vec2;
}

export const DEFAULT_KERNEL_SIZE = 0.3;

/**
 * Splatting arguments uniform data for GPU
 */
export class SplattingArgsUniform {
    public clippingBoxMin: vec4;
    public clippingBoxMax: vec4;
    public gaussianScaling: number;
    public maxShDeg: number;
    public showEnvMap: number;
    public mipSplatting: number;
    public kernelSize: number;
    public walltime: number;
    public sceneExtend: number;
    public _pad: number;
    public sceneCenter: vec4;

    constructor() {
        this.clippingBoxMin = vec4.fromValues(
            Number.NEGATIVE_INFINITY,
            Number.NEGATIVE_INFINITY, 
            Number.NEGATIVE_INFINITY,
            0.0
        );
        this.clippingBoxMax = vec4.fromValues(
            Number.POSITIVE_INFINITY,
            Number.POSITIVE_INFINITY,
            Number.POSITIVE_INFINITY,
            0.0
        );
        this.gaussianScaling = 1.0;
        this.maxShDeg = 3;
        this.showEnvMap = 1;
        this.mipSplatting = 0;
        this.kernelSize = DEFAULT_KERNEL_SIZE;
        this.walltime = 0.0;
        this.sceneCenter = vec4.fromValues(0.0, 0.0, 0.0, 0.0);
        this.sceneExtend = 1.0;
        this._pad = 0;
    }

    static fromArgsAndPc(args: SplattingArgs, pc: PointCloud): SplattingArgsUniform {
        const uniform = new SplattingArgsUniform();
        
        uniform.gaussianScaling = args.gaussianScaling;
        uniform.maxShDeg = args.maxShDeg;
        uniform.showEnvMap = args.showEnvMap ? 1 : 0;
        uniform.mipSplatting = (args.mipSplatting ?? (pc.mipSplatting ? pc.mipSplatting() : false) ?? false) ? 1 : 0;
        uniform.kernelSize = args.kernelSize ?? (pc.dilationKernelSize ? pc.dilationKernelSize() : DEFAULT_KERNEL_SIZE) ?? DEFAULT_KERNEL_SIZE;
        
        const bbox = pc.bbox();
        const clippingBox = args.clippingBox ?? bbox;
        vec4.set(uniform.clippingBoxMin, clippingBox.min.x, clippingBox.min.y, clippingBox.min.z, 0.0);
        vec4.set(uniform.clippingBoxMax, clippingBox.max.x, clippingBox.max.y, clippingBox.max.z, 0.0);
        
        uniform.walltime = args.walltime;
        const center = pc.center();
        vec4.set(uniform.sceneCenter, center.x, center.y, center.z, 0.0);
        uniform.sceneExtend = Math.max(args.sceneExtend ?? 1.0, 1.0);
        
        return uniform;
    }
}

/**
 * Preprocess pipeline for converting 3D gaussians to 2D
 */
class PreprocessPipeline {
    private pipeline: GPUComputePipeline;
    private static sortFallbackBGL: GPUBindGroupLayout | null = null;

    private constructor(pipeline: GPUComputePipeline) {
        this.pipeline = pipeline;
    }

    static async create(device: GPUDevice, shDeg: number, compressed: boolean): Promise<PreprocessPipeline> {
        const pipelineLayout = device.createPipelineLayout({
            label: 'preprocess pipeline layout',
            bindGroupLayouts: [
                UnifiedUniformBuffer.bindGroupLayout(device), // group(0) Camera + Settings uniforms
                compressed ? PointCloud.bindGroupLayoutCompressed(device) : PointCloud.bindGroupLayout(device), // group(1) Point cloud
                PreprocessPipeline.sortBindGroupLayout(device), // group(2) Sort buffers
            ]
        });

        const shaderCode = await PreprocessPipeline.buildShader(shDeg, compressed);
        const shader = device.createShaderModule({
            label: 'preprocess shader',
            code: shaderCode
        });

        const pipeline = device.createComputePipeline({
            label: 'preprocess pipeline',
            layout: pipelineLayout,
            compute: {
                module: shader,
                entryPoint: 'preprocess'
            }
        });

        return new PreprocessPipeline(pipeline);
    }

    private static async buildShader(shDeg: number, compressed: boolean): Promise<string> {
        // Load actual WGSL shader
        const wgslUrl = './shaders/preprocess.wgsl';
        console.log('[PP] wgsl url =', wgslUrl);
        const response = await fetch(wgslUrl);
        const wgslSource = await response.text();
        console.log('[PP] wgsl head =', wgslSource.substring(0, 160));
        const entryPoint = 'preprocess';
        console.log('[PP] entryPoint =', entryPoint);
        
        // Inject the MAX_SH_DEG constant (no-op for smoke test)
        return wgslSource.replace('//const MAX_SH_DEG:u32 = <injected>u;', `const MAX_SH_DEG:u32 = ${shDeg}u;`);
    }
    
    static sortBindGroupLayout(device: GPUDevice): GPUBindGroupLayout {
        if (!PreprocessPipeline.sortFallbackBGL) {
            PreprocessPipeline.sortFallbackBGL = device.createBindGroupLayout({
                label: 'sort bind group layout',
                entries: [
                    {
                        binding: 0,
                        visibility: GPUShaderStage.COMPUTE,
                        buffer: { type: 'storage' }
                    },
                    {
                        binding: 1,
                        visibility: GPUShaderStage.COMPUTE,
                        buffer: { type: 'storage' }
                    },
                    {
                        binding: 2,
                        visibility: GPUShaderStage.COMPUTE,
                        buffer: { type: 'storage' }
                    },
                    {
                        binding: 3,
                        visibility: GPUShaderStage.COMPUTE,
                        buffer: { type: 'storage' }
                    }
                ]
            });
        }
        return PreprocessPipeline.sortFallbackBGL;
    }
    

    run(
        encoder: GPUCommandEncoder,
        pc: PointCloud,
        unifiedUniform: UnifiedUniformBuffer,
        sortBg: GPUBindGroup
    ): void {
        const pass = encoder.beginComputePass({
            label: 'preprocess compute pass'
        });

        pass.setPipeline(this.pipeline);
        pass.setBindGroup(0, unifiedUniform.getBindGroup()); // Unified camera+settings
        pass.setBindGroup(1, pc.getBindGroup());
        pass.setBindGroup(2, sortBg);

        // Bind group validation logs
        console.log('[PP/BG] g0 unified BG?', !!unifiedUniform.getBindGroup());
        console.log('[PP/BG] g1 pointcloud BG?', !!pc.getBindGroup(), 'points_2d bytes', pc.getSplat2dBuffer().size);
        console.log('[PP/BG] g2 sort BG?', !!sortBg);

        const wgsX = Math.ceil(pc.numPoints() / 256);
        pass.dispatchWorkgroups(wgsX, 1, 1);
        pass.end();
    }
}

/**
 * Main Gaussian renderer
 */
export class GaussianRenderer {
    private pipeline: GPURenderPipeline;
    private unifiedUniform: UnifiedUniformBuffer;
    private preprocess: PreprocessPipeline;
    private drawIndirectBuffer: GPUBuffer;
    private drawIndirect: GPUBindGroup;
    private _colorFormat: GPUTextureFormat;
    private sorter: GPURSSorter | null = null; // Will be initialized when gpu_rs is ported
    private sorterStuff: PointCloudSortStuff | null = null;
    
    // Sort buffers for fallback path
    private sortInfosBuffer: GPUBuffer | null = null;
    private sortDepthsBuffer: GPUBuffer | null = null;
    private sortIndicesBuffer: GPUBuffer | null = null;
    private sortDispatchBuffer: GPUBuffer | null = null;
    private sortBg: GPUBindGroup | null = null;
    private _sortCount: number = 0;
    
    // Fallback bind group layout for sort buffers (group 2)
    private static sortFallbackBGL: GPUBindGroupLayout | null = null;
    
    // Indices bind group for fallback rendering
    private indicesBindGroup: GPUBindGroup | null = null;

    constructor(
        device: GPUDevice,
        queue: GPUQueue,
        colorFormat: GPUTextureFormat,
        shDeg: number,
        compressed: boolean,
        pipeline: GPURenderPipeline,
        unifiedUniform: UnifiedUniformBuffer,
        preprocess: PreprocessPipeline,
        drawIndirectBuffer: GPUBuffer,
        drawIndirect: GPUBindGroup
    ) {
        this.pipeline = pipeline;
        this.unifiedUniform = unifiedUniform;
        this.preprocess = preprocess;
        this.drawIndirectBuffer = drawIndirectBuffer;
        this.drawIndirect = drawIndirect;
        this._colorFormat = colorFormat;
    }

    // Matches Rust GPURSSorter::bind_group_layout_rendering - bindings 0 and 4 for indices
    static renderBindGroupLayout(device: GPUDevice): GPUBindGroupLayout {
        return device.createBindGroupLayout({
            label: 'render bind group layout',
            entries: [
                {
                    binding: 0,
                    visibility: GPUShaderStage.VERTEX,
                    buffer: { type: 'read-only-storage' }
                },
                {
                    binding: 4,
                    visibility: GPUShaderStage.VERTEX,
                    buffer: { type: 'read-only-storage' }
                }
            ]
        });
    }

    static async create(
        device: GPUDevice,
        queue: GPUQueue,
        colorFormat: GPUTextureFormat,
        shDeg: number,
        compressed: boolean
    ): Promise<GaussianRenderer> {
        const pipelineLayout = device.createPipelineLayout({
            label: 'render pipeline layout',
            bindGroupLayouts: [
                PointCloud.bindGroupLayoutRender(device),
                GaussianRenderer.renderBindGroupLayout(device), // For indices buffer (matches Rust GPURSSorter::bind_group_layout_rendering)
            ]
        });

        // Load shader from WGSL file
        const shaderCode = await fetch('./shaders/gaussian.wgsl').then(r => r.text());
        const shader = device.createShaderModule({
            label: 'gaussian shader',
            code: shaderCode
        });

        const pipeline = device.createRenderPipeline({
            label: 'render pipeline',
            layout: pipelineLayout,
            vertex: {
                module: shader,
                entryPoint: 'vs_main'
            },
            fragment: {
                module: shader,
                entryPoint: 'fs_main',
                targets: [{
                    format: colorFormat,
                    blend: {
                        color: {
                            srcFactor: 'one',
                            dstFactor: 'one-minus-src-alpha',
                            operation: 'add'
                        },
                        alpha: {
                            srcFactor: 'one',
                            dstFactor: 'one-minus-src-alpha', 
                            operation: 'add'
                        }
                    },
                    writeMask: GPUColorWrite.ALL
                }]
            },
            primitive: {
                topology: 'triangle-strip',
                frontFace: 'ccw'
            }
        });

        const drawIndirectBuffer = device.createBuffer({
            label: 'indirect draw buffer',
            size: 16, // Size of DrawIndirectArgs
            usage: GPUBufferUsage.INDIRECT | GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC
        });

        const indirectLayout = GaussianRenderer.bindGroupLayout(device);
        const drawIndirect = device.createBindGroup({
            label: 'draw indirect buffer',
            layout: indirectLayout,
            entries: [{
                binding: 0,
                resource: { buffer: drawIndirectBuffer }
            }]
        });

        const unifiedUniform = new UnifiedUniformBuffer(device, 'unified uniform buffer');
        const preprocess = await PreprocessPipeline.create(device, shDeg, compressed);

        return new GaussianRenderer(
            device,
            queue,
            colorFormat,
            shDeg,
            compressed,
            pipeline,
            unifiedUniform,
            preprocess,
            drawIndirectBuffer,
            drawIndirect
        );
    }

    getUnifiedUniform(): UnifiedUniformBuffer {
        return this.unifiedUniform;
    }

    private async preprocessStep(
        encoder: GPUCommandEncoder,
        queue: GPUQueue,
        pc: PointCloud,
        renderSettings: SplattingArgs,
        device: GPUDevice
    ): Promise<void> {
        // Update unified uniform buffer with camera and settings data
        // Create camera uniform data
        const cameraUniform = new CameraUniform();
        const focal = renderSettings.camera.projection.focal({ x: renderSettings.viewport[0], y: renderSettings.viewport[1] });
        cameraUniform.setFocal(vec2.fromValues(focal.x, focal.y));
        cameraUniform.setViewport(vec2.fromValues(renderSettings.viewport[0], renderSettings.viewport[1]));
        cameraUniform.setCamera(renderSettings.camera);
        
        // Create camera bytes directly - 272 bytes for camera uniform
        const cameraBuffer = new ArrayBuffer(272);
        const cameraView = new Float32Array(cameraBuffer);
        
        // Pack camera matrices (4x4 matrices = 16 floats each)
        for (let i = 0; i < 16; i++) {
            cameraView[i] = cameraUniform.viewMatrix[i];
            cameraView[16 + i] = cameraUniform.viewInvMatrix[i];
            cameraView[32 + i] = cameraUniform.projMatrix[i];
            cameraView[48 + i] = cameraUniform.projInvMatrix[i];
        }
        cameraView[64] = cameraUniform.viewport[0]; // viewport.x
        cameraView[65] = cameraUniform.viewport[1]; // viewport.y
        cameraView[66] = cameraUniform.focal[0]; // focal.x
        cameraView[67] = cameraUniform.focal[1]; // focal.y
        const cameraBytes = new Uint8Array(cameraBuffer);
        
        // Create settings bytes directly - 80 bytes for settings uniform
        const settingsUniform = SplattingArgsUniform.fromArgsAndPc(renderSettings, pc);
        const settingsBuffer = new ArrayBuffer(80);
        const settingsView = new Float32Array(settingsBuffer);
        settingsView[0] = settingsUniform.gaussianScaling;
        settingsView[1] = settingsUniform.maxShDeg;
        settingsView[2] = settingsUniform.showEnvMap;
        settingsView[3] = settingsUniform.mipSplatting;
        settingsView[4] = settingsUniform.kernelSize;
        settingsView[5] = settingsUniform.walltime;
        settingsView[6] = settingsUniform.sceneExtend;
        settingsView[7] = settingsUniform._pad;
        // Pack clipping box min (vec4 = 4 floats)
        for (let i = 0; i < 4; i++) {
            settingsView[8 + i] = settingsUniform.clippingBoxMin[i];
        }
        // Pack clipping box max (vec4 = 4 floats)
        for (let i = 0; i < 4; i++) {
            settingsView[12 + i] = settingsUniform.clippingBoxMax[i];
        }
        // Pack scene center (vec4 = 4 floats)
        for (let i = 0; i < 4; i++) {
            settingsView[16 + i] = settingsUniform.sceneCenter[i];
        }
        const settingsBytes = new Uint8Array(settingsBuffer);
        
        // Update unified buffer
        this.unifiedUniform.updateCamera(queue, cameraBytes);
        this.unifiedUniform.updateSettings(queue, settingsBytes);

        // Write indirect draw args
        const drawArgs = new ArrayBuffer(16);
        const view = new DataView(drawArgs);
        view.setUint32(0, 4, true); // vertex_count
        view.setUint32(4, 0, true); // instance_count
        view.setUint32(8, 0, true); // first_vertex
        view.setUint32(12, 0, true); // first_instance
        queue.writeBuffer(this.drawIndirectBuffer, 0, drawArgs);

        if (this.sorterStuff) {
            this.preprocess.run(
                encoder,
                pc,
                this.unifiedUniform,
                this.sorterStuff.sorterBg
            );
        }
    }
    
    private ensureSortBuffers(device: GPUDevice, pc: PointCloud): void {
        const count = pc.numPoints();
        if (!this.sortInfosBuffer || this._sortCount !== count) {
            console.log(`Creating sort buffers for ${count} points`);
            
            // Create sort buffers matching WGSL group(2) layout
            this.sortInfosBuffer = device.createBuffer({
                label: 'sort infos',
                size: 20, // SortInfos struct size
                usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC
            });

            this.sortDepthsBuffer = device.createBuffer({
                label: 'sort depths',
                size: count * 4, // f32 per point
                usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST
            });

            this.sortIndicesBuffer = device.createBuffer({
                label: 'sort indices',
                size: count * 4, // u32 per point
                usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST
            });

            this.sortDispatchBuffer = device.createBuffer({
                label: 'sort dispatch',
                size: 12, // 3 u32s for dispatch args
                usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST
            });

            // Create bind group for sort buffers (group 2)
            this.sortBg = device.createBindGroup({
                label: 'sort bind group',
                layout: PreprocessPipeline.sortBindGroupLayout(device),
                entries: [
                    { binding: 0, resource: { buffer: this.sortInfosBuffer } },
                    { binding: 1, resource: { buffer: this.sortDepthsBuffer } },
                    { binding: 2, resource: { buffer: this.sortIndicesBuffer } },
                    { binding: 3, resource: { buffer: this.sortDispatchBuffer } }
                ]
            });

            // Create indices bind group for rendering (group 1)
            this.indicesBindGroup = device.createBindGroup({
                label: 'indices bind group',
                layout: GaussianRenderer.renderBindGroupLayout(device),
                entries: [
                    { binding: 0, resource: { buffer: this.sortIndicesBuffer } },
                    { binding: 4, resource: { buffer: this.sortIndicesBuffer } }
                ]
            });

            this._sortCount = count;
        }
    }

    async prepare(
        encoder: GPUCommandEncoder,
        device: GPUDevice,
        queue: GPUQueue,
        pc: PointCloud,
        renderSettings: SplattingArgs,
        stopwatch?: GPUStopwatch
    ): Promise<void> {
        // Initialize sorter stuff if needed
        if (!this.sorterStuff || this.sorterStuff.numPoints !== pc.numPoints()) {
            console.log(`Created sort buffers for ${pc.numPoints()} points`);
            if (this.sorter) {
                this.sorterStuff = this.sorter.createSortStuff(device, pc.numPoints());
            }
        }

        if (this.sorter && this.sorterStuff) {
            this.sorter.recordResetIndirectBuffer(
                this.sorterStuff.sorterDis,
                this.sorterStuff.sorterUni,
                queue
            );
        }

        // Preprocess step
        if (stopwatch) {
            stopwatch.start(encoder, 'preprocess');
        }
        await this.preprocessStep(encoder, queue, pc, renderSettings, device);
        if (stopwatch) {
            stopwatch.stop(encoder, 'preprocess');
        }

        // Sorting step
        if (stopwatch) {
            stopwatch.start(encoder, 'sorting');
        }
        if (this.sorter && this.sorterStuff) {
            this.sorter.recordSortIndirect(
                this.sorterStuff.sorterBg,
                this.sorterStuff.sorterDis,
                encoder
            );
        }
        if (stopwatch) {
            stopwatch.stop(encoder, 'sorting');
        }

        // Copy buffer
        if (this.sorterStuff) {
            encoder.copyBufferToBuffer(
                this.sorterStuff.sorterUni,
                0,
                this.drawIndirectBuffer,
                4, // offset to instance_count
                4  // size of u32
            );
        } else {
            // Fallback: ensure sort buffers exist and run preprocess
            this.ensureSortBuffers(device, pc);
            
            // Initialize sort infos with point count
            const sortInfosData = new ArrayBuffer(8);
            const sortInfosView = new DataView(sortInfosData);
            sortInfosView.setUint32(0, 0, true); // keys_size = 0 initially
            sortInfosView.setUint32(4, pc.numPoints(), true); // total_count
            queue.writeBuffer(this.sortInfosBuffer!, 0, sortInfosData);
            
            // Run preprocess with unified uniform
            this.preprocess.run(encoder, pc, this.unifiedUniform, this.sortBg!);
            
            // Copy sort infos keys_size to drawIndirectBuffer instance_count
            encoder.copyBufferToBuffer(
                this.sortInfosBuffer!,
                0, // keys_size offset
                this.drawIndirectBuffer,
                4, // instance_count offset
                4  // size of u32
            );
        }
    }

    render(renderPass: GPURenderPassEncoder, pc: PointCloud): void {
        renderPass.setBindGroup(0, pc.getRenderBindGroup());
        if (this.sorterStuff) {
            renderPass.setBindGroup(1, this.sorterStuff.sorterRenderBg);
        } else {
            // Fallback: bind indices bind group at group 1
            renderPass.setBindGroup(1, this.indicesBindGroup!);
        }
        renderPass.setPipeline(this.pipeline);
        renderPass.drawIndirect(this.drawIndirectBuffer, 0);
    }

    static bindGroupLayout(device: GPUDevice): GPUBindGroupLayout {
        return device.createBindGroupLayout({
            label: 'draw indirect',
            entries: [{
                binding: 0,
                visibility: GPUShaderStage.COMPUTE,
                buffer: {
                    type: 'storage'
                }
            }]
        });
    }

    getDrawIndirectBuffer(): GPUBuffer {
        return this.drawIndirectBuffer;
    }

    getColorFormat(): GPUTextureFormat {
        return this._colorFormat;
    }
}

/**
 * Display pipeline for final rendering to screen
 */
export class Display {
    private pipeline: GPURenderPipeline;
    private bindGroup: GPUBindGroup;
    private format: GPUTextureFormat;
    private view: GPUTextureView;
    private envBg: GPUBindGroup;
    private hasEnvMap: boolean;

    constructor(
        device: GPUDevice,
        sourceFormat: GPUTextureFormat,
        targetFormat: GPUTextureFormat,
        width: number,
        height: number
    ) {
        const pipelineLayout = device.createPipelineLayout({
            label: 'display pipeline layout',
            bindGroupLayouts: [
                Display.bindGroupLayout(device),
                Display.envMapBindGroupLayout(device),
                UniformBuffer.bindGroupLayout(device), // Camera uniform
                UniformBuffer.bindGroupLayout(device), // Render settings uniform
            ]
        });

        // Load display shader
        const shader = device.createShaderModule({
            label: 'display shader',
            code: `
                // Placeholder display shader
                @vertex
                fn vs_main(@builtin(vertex_index) vertex_index: u32) -> @builtin(position) vec4<f32> {
                    var pos = array<vec2<f32>, 4>(
                        vec2<f32>(-1.0, -1.0),
                        vec2<f32>( 1.0, -1.0),
                        vec2<f32>(-1.0,  1.0),
                        vec2<f32>( 1.0,  1.0)
                    );
                    return vec4<f32>(pos[vertex_index], 0.0, 1.0);
                }

                @fragment
                fn fs_main() -> @location(0) vec4<f32> {
                    return vec4<f32>(1.0, 0.0, 0.0, 1.0);
                }
            `
        });

        this.pipeline = device.createRenderPipeline({
            label: 'display pipeline',
            layout: pipelineLayout,
            vertex: {
                module: shader,
                entryPoint: 'vs_main'
            },
            fragment: {
                module: shader,
                entryPoint: 'fs_main',
                targets: [{
                    format: targetFormat,
                    blend: {
                        color: {
                            srcFactor: 'one',
                            dstFactor: 'one-minus-src-alpha',
                            operation: 'add'
                        },
                        alpha: {
                            srcFactor: 'one',
                            dstFactor: 'one-minus-src-alpha',
                            operation: 'add'
                        }
                    },
                    writeMask: GPUColorWrite.ALL
                }]
            },
            primitive: {
                topology: 'triangle-strip'
            }
        });

        this.envBg = Display.createEnvMapBg(device, null);
        const [view, bindGroup] = Display.createRenderTarget(device, sourceFormat, width, height);
        
        this.format = sourceFormat;
        this.view = view;
        this.bindGroup = bindGroup;
        this.hasEnvMap = false;
    }

    texture(): GPUTextureView {
        return this.view;
    }

    private static envMapBindGroupLayout(device: GPUDevice): GPUBindGroupLayout {
        return device.createBindGroupLayout({
            label: 'env map bind group layout',
            entries: [
                {
                    binding: 0,
                    visibility: GPUShaderStage.FRAGMENT,
                    texture: {
                        sampleType: 'float',
                        viewDimension: '2d'
                    }
                },
                {
                    binding: 1,
                    visibility: GPUShaderStage.FRAGMENT,
                    sampler: {
                        type: 'filtering'
                    }
                }
            ]
        });
    }

    private static createEnvMapBg(device: GPUDevice, envTexture: GPUTextureView | null): GPUBindGroup {
        const placeholderTexture = device.createTexture({
            label: 'placeholder',
            size: { width: 1, height: 1 },
            format: 'rgba16float',
            usage: GPUTextureUsage.TEXTURE_BINDING
        }).createView();

        const textureView = envTexture || placeholderTexture;
        const sampler = device.createSampler({
            label: 'env map sampler',
            magFilter: 'linear',
            minFilter: 'linear'
        });

        return device.createBindGroup({
            label: 'env map bind group',
            layout: Display.envMapBindGroupLayout(device),
            entries: [
                {
                    binding: 0,
                    resource: textureView
                },
                {
                    binding: 1,
                    resource: sampler
                }
            ]
        });
    }

    setEnvMap(device: GPUDevice, envTexture: GPUTextureView | null): void {
        this.envBg = Display.createEnvMapBg(device, envTexture);
        this.hasEnvMap = envTexture !== null;
    }

    hasEnvMapSet(): boolean {
        return this.hasEnvMap;
    }

    private static createRenderTarget(
        device: GPUDevice,
        format: GPUTextureFormat,
        width: number,
        height: number
    ): [GPUTextureView, GPUBindGroup] {
        const texture = device.createTexture({
            label: 'display render image',
            size: { width, height },
            format,
            usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.RENDER_ATTACHMENT
        });

        const textureView = texture.createView();
        const sampler = device.createSampler({
            magFilter: 'linear',
            minFilter: 'linear'
        });

        const bindGroup = device.createBindGroup({
            label: 'render target bind group',
            layout: Display.bindGroupLayout(device),
            entries: [
                {
                    binding: 0,
                    resource: textureView
                },
                {
                    binding: 1,
                    resource: sampler
                }
            ]
        });

        return [textureView, bindGroup];
    }

    static bindGroupLayout(device: GPUDevice): GPUBindGroupLayout {
        return device.createBindGroupLayout({
            label: 'display bind group layout',
            entries: [
                {
                    binding: 0,
                    visibility: GPUShaderStage.FRAGMENT,
                    texture: {
                        sampleType: 'float',
                        viewDimension: '2d'
                    }
                },
                {
                    binding: 1,
                    visibility: GPUShaderStage.FRAGMENT,
                    sampler: {
                        type: 'filtering'
                    }
                }
            ]
        });
    }

    resize(device: GPUDevice, width: number, height: number): void {
        const [view, bindGroup] = Display.createRenderTarget(device, this.format, width, height);
        this.bindGroup = bindGroup;
        this.view = view;
    }

    render(
        encoder: GPUCommandEncoder,
        target: GPUTextureView,
        backgroundColor: GPUColor,
        camera: UniformBuffer<CameraUniform>,
        renderSettings: UniformBuffer<SplattingArgsUniform>
    ): void {
        const renderPass = encoder.beginRenderPass({
            label: 'render pass',
            colorAttachments: [{
                view: target,
                clearValue: backgroundColor,
                loadOp: 'clear',
                storeOp: 'store'
            }]
        });

        renderPass.setBindGroup(0, this.bindGroup);
        renderPass.setBindGroup(1, this.envBg);
        renderPass.setBindGroup(2, camera.getBindGroup());
        renderPass.setBindGroup(3, renderSettings.getBindGroup());
        renderPass.setPipeline(this.pipeline);
        renderPass.draw(4, 1);
        renderPass.end();
    }
}
