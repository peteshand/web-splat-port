/**
 * TypeScript port of uniform.rs
 * Manages uniform buffers for WebGPU
 */

// Type constraints equivalent to Rust's NoUninit + Pod
export interface BufferData {
    // Data that can be safely cast to bytes for GPU buffers
}

// Unified uniform buffer constants
const CAMERA_SIZE = 272;
const SETTINGS_SIZE = 80;
const UNIFIED_BUFFER_SIZE = 512;

/**
 * Unified uniform buffer that combines camera and settings uniforms
 * Camera at offset 0 (272 bytes), Settings at offset 256 (80 bytes)
 */
export class UnifiedUniformBuffer {
    private buffer: GPUBuffer;
    private bindGroup: GPUBindGroup;
    private cameraData: Uint8Array;
    private settingsData: Uint8Array;

    constructor(device: GPUDevice, label?: string) {
        // Create single 512-byte buffer
        this.buffer = device.createBuffer({
            label: label || 'unified uniform buffer',
            size: UNIFIED_BUFFER_SIZE,
            usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
            mappedAtCreation: false
        });

        // Initialize data arrays
        this.cameraData = new Uint8Array(CAMERA_SIZE);
        this.settingsData = new Uint8Array(SETTINGS_SIZE);

        // Create bind group with both bindings
        this.bindGroup = device.createBindGroup({
            label: `${label || 'unified'} bind group`,
            layout: UnifiedUniformBuffer.bindGroupLayout(device),
            entries: [
                {
                    binding: 0, // Camera uniform
                    resource: {
                        buffer: this.buffer,
                        offset: 0,
                        size: CAMERA_SIZE
                    }
                },
                {
                    binding: 1, // Settings uniform  
                    resource: {
                        buffer: this.buffer,
                        offset: 256,
                        size: SETTINGS_SIZE
                    }
                }
            ]
        });
    }

    static bindGroupLayout(device: GPUDevice): GPUBindGroupLayout {
        return device.createBindGroupLayout({
            label: "unified uniform bind group layout",
            entries: [
                {
                    binding: 0, // Camera
                    visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT | GPUShaderStage.COMPUTE,
                    buffer: {
                        type: "uniform",
                        hasDynamicOffset: false,
                        minBindingSize: CAMERA_SIZE
                    }
                },
                {
                    binding: 1, // Settings
                    visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT | GPUShaderStage.COMPUTE,
                    buffer: {
                        type: "uniform", 
                        hasDynamicOffset: false,
                        minBindingSize: SETTINGS_SIZE
                    }
                }
            ]
        });
    }

    updateCamera(queue: GPUQueue, cameraBytes: Uint8Array): void {
        console.log('[UNI] cameraBytes.length', cameraBytes.length);
        if (cameraBytes.length !== CAMERA_SIZE) {
            throw new Error(`Camera data must be exactly ${CAMERA_SIZE} bytes, got ${cameraBytes.length}`);
        }
        this.cameraData.set(cameraBytes);
        queue.writeBuffer(this.buffer, 0, cameraBytes.buffer);
    }

    updateSettings(queue: GPUQueue, settingsBytes: Uint8Array): void {
        console.log('[UNI] settingsBytes.length', settingsBytes.length);
        if (settingsBytes.length !== SETTINGS_SIZE) {
            throw new Error(`Settings data must be exactly ${SETTINGS_SIZE} bytes, got ${settingsBytes.length}`);
        }
        this.settingsData.set(settingsBytes);
        queue.writeBuffer(this.buffer, 256, settingsBytes.buffer);
    }

    getBuffer(): GPUBuffer {
        return this.buffer;
    }

    getBindGroup(): GPUBindGroup {
        return this.bindGroup;
    }
}

export class UniformBuffer<T extends BufferData> {
    private buffer: GPUBuffer;
    private data: T;
    private label: string | null;
    private bindGroup: GPUBindGroup;

    constructor(
        device: GPUDevice,
        data: T,
        label?: string
    ) {
        this.data = data;
        this.label = label || null;

        // Create buffer with data
        const dataArray = this.castToBytes(data);
        this.buffer = device.createBuffer({
            label: label,
            size: dataArray.byteLength,
            usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
            mappedAtCreation: true
        });

        // Write initial data
        new Uint8Array(this.buffer.getMappedRange()).set(dataArray);
        this.buffer.unmap();

        // Create bind group
        const bgLabel = label ? `${label} bind group` : undefined;
        this.bindGroup = device.createBindGroup({
            label: bgLabel,
            layout: UniformBuffer.bindGroupLayout(device),
            entries: [{
                binding: 0,
                resource: {
                    buffer: this.buffer
                }
            }]
        });
    }

    static newDefault<T extends BufferData>(
        device: GPUDevice,
        defaultData: T,
        label?: string
    ): UniformBuffer<T> {
        return new UniformBuffer(device, defaultData, label);
    }

    static new<T extends BufferData>(
        device: GPUDevice,
        data: T,
        label?: string
    ): UniformBuffer<T> {
        return new UniformBuffer(device, data, label);
    }

    getBuffer(): GPUBuffer {
        return this.buffer;
    }

    getData(): T {
        return this.data;
    }

    getBindGroup(): GPUBindGroup {
        return this.bindGroup;
    }

    static bindGroupLayout(device: GPUDevice): GPUBindGroupLayout {
        return device.createBindGroupLayout({
            label: "uniform bind group layout",
            entries: [{
                binding: 0,
                visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT | GPUShaderStage.COMPUTE,
                buffer: {
                    type: "uniform",
                    hasDynamicOffset: false,
                    minBindingSize: undefined // Will be determined by buffer size
                }
            }]
        });
    }

    /**
     * Uploads data from CPU to GPU if necessary
     */
    sync(queue: GPUQueue): void {
        // For now, we'll use a simplified approach
        // In a full implementation, this would serialize the data properly
        const data = new ArrayBuffer(256); // Placeholder size
        queue.writeBuffer(this.buffer, 0, data);
    }

    static bindingType(): GPUBufferBindingLayout {
        return {
            type: "uniform" as const,
            hasDynamicOffset: false,
            minBindingSize: undefined
        };
    }

    clone(device: GPUDevice, queue: GPUQueue): UniformBuffer<T> {
        // Create new buffer with same size
        const newBuffer = device.createBuffer({
            label: this.label || undefined,
            usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
            size: this.buffer.size,
            mappedAtCreation: false
        });

        // Copy buffer contents
        const encoder = device.createCommandEncoder({
            label: "copy uniform buffer encoder"
        });
        encoder.copyBufferToBuffer(
            this.buffer, 0,
            newBuffer, 0,
            this.buffer.size
        );
        queue.submit([encoder.finish()]);

        // Create new bind group
        const bindGroup = device.createBindGroup({
            label: "uniform bind group",
            layout: UniformBuffer.bindGroupLayout(device),
            entries: [{
                binding: 0,
                resource: {
                    buffer: newBuffer
                }
            }]
        });

        // Create new instance with copied data
        const cloned = Object.create(UniformBuffer.prototype);
        cloned.buffer = newBuffer;
        cloned.data = { ...this.data }; // Shallow clone of data
        cloned.label = this.label;
        cloned.bindGroup = bindGroup;
        return cloned;
    }

    /**
     * Get mutable reference to data (equivalent to AsMut<T>)
     */
    asMut(): T {
        return this.data;
    }

    /**
     * Convert data to byte array for GPU buffer
     * This is equivalent to bytemuck::cast_slice in Rust
     */
    private castToBytes(data: T): Uint8Array {
        // For simple numeric types, convert to ArrayBuffer
        if (typeof data === 'number') {
            const buffer = new ArrayBuffer(4);
            new Float32Array(buffer)[0] = data;
            return new Uint8Array(buffer);
        }
        
        // For objects with numeric properties, serialize to binary layout
        if (typeof data === 'object' && data !== null) {
            // Check if it's a CameraUniform or SplattingArgsUniform
            if ('viewMatrix' in data && 'projMatrix' in data) {
                // CameraUniform: 2 mat4 = 128 bytes, padded to 256
                const buffer = new ArrayBuffer(256);
                const view = new DataView(buffer);
                const floatView = new Float32Array(buffer);
                
                // viewMatrix (16 f32)
                for (let i = 0; i < 16; i++) {
                    floatView[i] = (data as any).viewMatrix[i];
                }
                // projMatrix (16 f32)
                for (let i = 0; i < 16; i++) {
                    floatView[16 + i] = (data as any).projMatrix[i];
                }
                
                return new Uint8Array(buffer);
            }
            
            if ('gaussianScaling' in data) {
                // SplattingArgsUniform: padded to 256 bytes
                const buffer = new ArrayBuffer(256);
                const view = new DataView(buffer);
                let offset = 0;
                
                // gaussianScaling: f32
                view.setFloat32(offset, (data as any).gaussianScaling, true);
                offset += 4;
                
                // maxShDeg: u32
                view.setUint32(offset, (data as any).maxShDeg, true);
                offset += 4;
                
                // showEnvMap: u32
                view.setUint32(offset, (data as any).showEnvMap, true);
                offset += 4;
                
                // mipSplatting: u32
                view.setUint32(offset, (data as any).mipSplatting, true);
                offset += 4;
                
                // kernelSize: f32
                view.setFloat32(offset, (data as any).kernelSize, true);
                offset += 4;
                
                // Padding to align vec4
                offset = Math.ceil(offset / 16) * 16;
                
                // clippingBoxMin: vec4<f32>
                for (let i = 0; i < 4; i++) {
                    view.setFloat32(offset + i * 4, (data as any).clippingBoxMin[i], true);
                }
                offset += 16;
                
                // clippingBoxMax: vec4<f32>
                for (let i = 0; i < 4; i++) {
                    view.setFloat32(offset + i * 4, (data as any).clippingBoxMax[i], true);
                }
                offset += 16;
                
                // walltime: f32
                view.setFloat32(offset, (data as any).walltime, true);
                offset += 4;
                
                // Padding to align vec4
                offset = Math.ceil(offset / 16) * 16;
                
                // sceneCenter: vec4<f32>
                for (let i = 0; i < 4; i++) {
                    view.setFloat32(offset + i * 4, (data as any).sceneCenter[i], true);
                }
                offset += 16;
                
                // sceneExtend: f32
                view.setFloat32(offset, (data as any).sceneExtend, true);
                
                return new Uint8Array(buffer);
            }
            
            // Fallback for unknown objects
            throw new Error(`Unsupported object type for GPU buffer: ${Object.keys(data)}`);
        }

        throw new Error('Unsupported data type for GPU buffer');
    }
}
