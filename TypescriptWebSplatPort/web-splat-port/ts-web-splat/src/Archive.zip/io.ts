// Re-export IO barrel to keep imports like "./io.js" working
export * from "./io/index.js";
